#!/bin/bash

# Konfiguracja pliku wp-config.php
cd /var/www/html/wordpress
cp wp-config-sample.php wp-config.php

# Ustawienie danych dostępowych do bazy danych
sed -i "s/database_name_here/${WORDPRESS_DB_NAME}/" wp-config.php
sed -i "s/username_here/${WORDPRESS_DB_USER}/" wp-config.php
sed -i "s/password_here/${WORDPRESS_DB_PASSWORD}/" wp-config.php
sed -i "s/localhost/${WORDPRESS_DB_HOST}/" wp-config.php

