CREATE DATABASE IF NOT EXISTS wordpress_db;

CREATE USER IF NOT EXISTS wordpress_user@'%' IDENTIFIED BY 'password';

GRANT ALL PRIVILEGES ON wordpress_db.* TO wordpress_user@'%';

FLUSH PRIVILEGES;